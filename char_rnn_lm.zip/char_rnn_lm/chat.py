"""
Interactive Command-Line Prompt Loop for Character-Level GRU.
Type your prompt and get completions until typing 'exit' or 'quit'.
"""

import os
import sys
import torch
from generate import load_model_and_tokenizer, generate_text

# Ensure safe UTF-8 terminal output on Windows
if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass


def interactive_chat():
    device = "cuda" if torch.cuda.is_available() else "cpu"
    checkpoint_path = os.path.join("checkpoints", "best_model.pt")

    if not os.path.exists(checkpoint_path):
        print(f"[ERROR] Checkpoint '{checkpoint_path}' not found!")
        print("👉 Pehle model train karein: python train.py --steps 500")
        return

    model, tokenizer, cfg, step, val_loss = load_model_and_tokenizer(checkpoint_path, device=device)

    print("=" * 65)
    print("💬 Interactive Model Chat & Text Completion")
    print("=" * 65)
    print(f"Loaded Model Checkpoint: {checkpoint_path} (Val Loss: {val_loss:.4f})")
    print("Instructions:")
    print("  • Koi bhi prompt type karein (Hindi, Hinglish, ya English).")
    print("  • Model aage ka text predict karega.")
    print("  • Exit karne ke liye 'exit' ya 'quit' type karein.")
    print("=" * 65)

    temperature = 0.75
    max_tokens = 120

    while True:
        try:
            prompt = input("\n📝 Aapka Prompt > ").strip()
            if prompt.lower() in ("exit", "quit", "q"):
                print("\nAlvida! Chat session ended.")
                break
            if not prompt:
                continue

            print("\n🤖 Model Completion:")
            print("-" * 50)
            completed_text = generate_text(
                model,
                tokenizer,
                prompt=prompt,
                max_new_tokens=max_tokens,
                temperature=temperature,
                top_k=40,
                top_p=0.9,
                device=device
            )
            print(completed_text)
            print("-" * 50)
        except (KeyboardInterrupt, EOFError):
            print("\nSession ended.")
            break


if __name__ == "__main__":
    interactive_chat()
